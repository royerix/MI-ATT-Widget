// Variables used by Scriptable.
// Estas deben estar al principio del archivo. No editar.
// icon-color: blue; icon-glyph: signal;

/**
 * MI AT&T - VERSIÓN 1.6 PREPAGO
 * Diseño unificado con la identidad visual de Pospago V16.4.
 *
 * Conserva la información y extracción de V1.5:
 * consumo MB/GB, total, disponible, porcentaje, días de vigencia
 * y fecha exacta de expiración.
 *
 * Widgets: pequeño, mediano, grande, accessoryInline,
 * accessoryCircular y accessoryRectangular.
 *
 * Reutiliza la sesión persistente del WebView cuando AT&T la conserva.
 * Solo solicita acceso manual si la sesión no existe o caducó.
 * No almacena credenciales. Conserva la caché válida de V1.3.
 */

const CONFIG = {
  portalURL: "https://miattweb.att.com.mx/",
  cacheFileName: "miatt_v1_3_prepago_cache.json",
  refreshIntervalMinutes: 60,

  // Paleta AT&T: igual a Pospago V16.4
  background: "#101820",
  panel: "#1D2A38",
  track: "#283447",
  blue: "#00A8E0",
  pink: "#D6295B",
  white: "#FFFFFF",
  secondary: "#AAB7C4",
  muted: "#8996A8",
  green: "#20C878"
};

const fm = FileManager.local();
const cachePath = fm.joinPath(fm.documentsDirectory(), CONFIG.cacheFileName);

// ======================================================
// UTILIDADES Y CACHÉ
// ======================================================

function sleep(seconds) {
  return new Promise(resolve => Timer.schedule(seconds, false, resolve));
}

function formatGB(value) {
  return Number.isFinite(Number(value)) ? Number(value).toFixed(2) : "--";
}

function formatTime(value) {
  const date = new Date(value);
  if (isNaN(date.getTime())) return "--:--";
  return date.toLocaleTimeString("es-MX", {
    hour: "2-digit", minute: "2-digit", hour12: true
  });
}

function formatDate(isoDate) {
  if (!isoDate) return "--";
  const parts = isoDate.split("-").map(Number);
  if (parts.length !== 3) return "--";
  const date = new Date(parts[0], parts[1] - 1, parts[2], 12);
  return date.toLocaleDateString("es-MX", {
    day: "numeric", month: "short", year: "numeric"
  });
}

function parseNumber(value) {
  if (value === null || value === undefined) return NaN;
  return parseFloat(String(value).replace(/\s/g, "").replace(",", "."));
}

function readCache() {
  try {
    if (!fm.fileExists(cachePath)) return null;
    const data = JSON.parse(fm.readString(cachePath));
    if (
      !data ||
      !Number.isFinite(Number(data.totalGB)) ||
      !Number.isFinite(Number(data.consumedGB)) ||
      !Number.isFinite(Number(data.availableGB))
    ) return null;
    return data;
  } catch (error) {
    console.log("Error leyendo caché: " + error);
    return null;
  }
}

function saveCache(data) {
  try {
    fm.writeString(cachePath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.log("Error guardando caché: " + error);
    return false;
  }
}

// ======================================================
// INSPECCIÓN DEL PORTAL
// ======================================================

async function inspectPageState(webView) {
  return await webView.evaluateJavaScript(`
    (() => {
      const body = document.body ? document.body.innerText : "";
      const normalized = body.normalize("NFD")
        .replace(/[\\u0300-\\u036f]/g, "")
        .replace(/\\s+/g, " ").toLowerCase();

      const hasUsage = /(?:ha|has)\\s+consumido\\s+[\\d.,]+\\s*(?:mb|gb)/i.test(normalized);
      const hasPrepaid = normalized.includes("att prepago") ||
                         normalized.includes("mi paquete");
      const hasDashboard = hasUsage ||
        (hasPrepaid && (normalized.includes("expira") ||
                        normalized.includes("disponible")));

      const visible = el => {
        const style = getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        return style.display !== "none" && style.visibility !== "hidden" &&
               rect.width > 0 && rect.height > 0;
      };

      return {
        hasDashboard,
        hasPassword: Array.from(document.querySelectorAll('input[type="password"]')).some(visible),
        url: location.href || "",
        title: document.title || "",
        text: body.substring(0, 3000)
      };
    })();
  `);
}

// Optimización segura: además del dashboard, detecta inmediatamente
// el formulario de acceso visible. Evita esperar los 10 segundos completos
// cuando AT&T ya está solicitando iniciar sesión.
async function waitForDashboard(webView, seconds) {
  const start = Date.now();
  while (Date.now() - start < seconds * 1000) {
    const state = await inspectPageState(webView);
    if (state && (state.hasDashboard || state.hasPassword)) return state;
    await sleep(1);
  }
  return await inspectPageState(webView);
}

// ======================================================
// EXTRACCIÓN DE TEXTO VISIBLE
// ======================================================

async function inspectDashboard(webView) {
  return await webView.evaluateJavaScript(`
    (() => {
      const selectors = [
        "app-my-plan", "app-progress-guage", "app-progress-bar",
        "app-my-package", "app-package"
      ];
      const texts = [], found = [];

      const addText = value => {
        if (value === null || value === undefined) return;
        const clean = String(value).replace(/\\s+/g, " ").trim();
        if (clean && !texts.includes(clean)) texts.push(clean);
      };

      for (const selector of selectors) {
        const nodes = Array.from(document.querySelectorAll(selector));
        if (nodes.length) found.push(selector);
        for (const node of nodes) {
          addText(node.innerText || node.textContent);
          node.querySelectorAll("svg text, svg tspan").forEach(el => addText(el.textContent));
          node.querySelectorAll("[aria-label],[title],[data-value],[data-label]").forEach(el => {
            addText(el.getAttribute("aria-label"));
            addText(el.getAttribute("title"));
            addText(el.getAttribute("data-value"));
            addText(el.getAttribute("data-label"));
          });
        }
      }

      return {
        title: document.title || "",
        url: location.href || "",
        componentText: texts.join("\\n"),
        foundComponents: found,
        bodyText: document.body ? document.body.innerText.substring(0, 20000) : "",
        timestamp: new Date().toISOString()
      };
    })();
  `);
}

// ======================================================
// PARSEO DE MB, GB Y VIGENCIA
// ======================================================

function convertToGB(value, unit) {
  const n = parseNumber(value);
  if (!Number.isFinite(n)) return NaN;
  return String(unit).toUpperCase() === "MB" ? n / 1024 : n;
}

function findMatch(text, regex) {
  const match = text.match(regex);
  return match ? match : null;
}

function parseDashboardText(report) {
  const normalize = value => String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();

  const sources = [
    { text: normalize(report.componentText), name: "COMPONENTES_DOM" },
    { text: normalize(report.bodyText), name: "BODY_RESPALDO" }
  ].filter(source => source.text);

  if (!sources.length) throw new Error("No se pudo leer el texto del dashboard.");

  let consumedGB = NaN, totalGB = NaN, availableGB = NaN;
  let consumedMB = NaN, daysLeft = null, expirationDate = null;
  let sourceUsed = "BODY_RESPALDO";

  for (const source of sources) {
    let m = source.text.match(/(?:ha|has)\s+consumido\s+([\d.,]+)\s*(MB|GB)\s+de\s+([\d.,]+)\s*GB/i);
    if (!m) {
      m = source.text.match(/(?:consumido|consumida)\s*:?\s*([\d.,]+)\s*(MB|GB)\b/i);
    }
    if (m) {
      const amount = parseNumber(m[1]);
      consumedGB = convertToGB(amount, m[2]);
      consumedMB = m[2].toUpperCase() === "MB" ? amount : amount * 1024;
      if (m[3] !== undefined) totalGB = parseNumber(m[3]);
      sourceUsed = source.name;
      break;
    }
  }

  if (!Number.isFinite(totalGB)) {
    for (const source of sources) {
      const patterns = [
        /\bde\s+([\d.,]+)\s*GB\b/i,
        /(?:total|incluidos|incluido)\s*:?\s*([\d.,]+)\s*GB\b/i,
        /total\s+saldo\s+internet\s*:?\s*([\d.,]+)\s*GB\b/i
      ];
      for (const pattern of patterns) {
        const m = source.text.match(pattern);
        if (m) { totalGB = parseNumber(m[1]); break; }
      }
      if (Number.isFinite(totalGB)) break;
    }
  }

  for (const source of sources) {
    let m = source.text.match(/([\d.,]+)\s*GB\s*(?:disponible|disponibles)\b/i);
    if (!m) m = source.text.match(/(?:disponible|disponibles)\s*:?\s*([\d.,]+)\s*GB\b/i);
    if (m) { availableGB = parseNumber(m[1]); break; }
  }

  if (!Number.isFinite(availableGB) && Number.isFinite(totalGB) && Number.isFinite(consumedGB)) {
    availableGB = totalGB - consumedGB;
  }
  if (!Number.isFinite(consumedGB) && Number.isFinite(totalGB) && Number.isFinite(availableGB)) {
    consumedGB = totalGB - availableGB;
    consumedMB = consumedGB * 1024;
  }

  for (const source of sources) {
    const m = source.text.match(/(?:restan|quedan)\s+(\d+)\s+dias?/i) ||
      source.text.match(/(\d+)\s+dias?\s+para\s+corte/i);
    if (m) { daysLeft = parseInt(m[1], 10); break; }
  }

  const monthMap = {
    enero: "01", ene: "01", febrero: "02", feb: "02", marzo: "03", mar: "03", abril: "04", abr: "04",
    mayo: "05", may: "05", junio: "06", jun: "06", julio: "07", jul: "07", agosto: "08", ago: "08",
    septiembre: "09", setiembre: "09", sep: "09", sept: "09", octubre: "10", oct: "10",
    noviembre: "11", nov: "11", diciembre: "12", dic: "12"
  };

  for (const source of sources) {
    const m = source.text.match(/(?:expira\s+el|vigencia\s+hasta|vence\s+el)\s*:?\s*(\d{1,2})\s+(enero|ene|febrero|feb|marzo|mar|abril|abr|mayo|may|junio|jun|julio|jul|agosto|ago|septiembre|setiembre|sept|sep|octubre|oct|noviembre|nov|diciembre|dic)\s+(\d{4})/i);
    if (m) {
      expirationDate = `${m[3]}-${monthMap[m[2].toLowerCase()]}-${String(m[1]).padStart(2, "0")}`;
      break;
    }
  }

  if (daysLeft === null && expirationDate) {
    const p = expirationDate.split("-").map(Number);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const expiry = new Date(p[0], p[1] - 1, p[2]);
    daysLeft = Math.max(0, Math.ceil((expiry - today) / 86400000));
  }

  if (!Number.isFinite(consumedGB) || !Number.isFinite(totalGB) || !Number.isFinite(availableGB)) {
    console.log("Diagnóstico de lectura: consumo=" + Number.isFinite(consumedGB) + ", total=" + Number.isFinite(totalGB) + ", disponible=" + Number.isFinite(availableGB) + ", texto_componentes=" + (report.componentText || "").length + ", texto_pagina=" + (report.bodyText || "").length);
    throw new Error("No se pudieron identificar consumo, total y disponible. Consulta el diagnóstico del registro.");
  }

  if (totalGB <= 0 || consumedGB < 0 || availableGB < 0 ||
      consumedGB > totalGB + 0.05 || availableGB > totalGB + 0.05) {
    throw new Error("Los datos extraídos no superaron la validación.");
  }

  return {
    success: true,
    planName: "AT&T Prepago",
    packageType: "Paquete promocional",
    totalGB,
    consumedGB,
    consumedMB,
    availableGB,
    percentUsed: Math.max(0, Math.min(100, consumedGB / totalGB * 100)),
    daysLeft,
    expirationDate,
    extractionSource: sourceUsed,
    updatedAt: report.timestamp || new Date().toISOString(),
    fromCache: false
  };
}

// ======================================================
// ACTUALIZAR AT&T — INICIO DE SESIÓN MANUAL
// ======================================================

async function updateATTData() {
  const webView = new WebView();

  try {
    console.log("Abriendo portal AT&T y comprobando sesión guardada...");
    await webView.loadURL(CONFIG.portalURL);

    const initialState = await waitForDashboard(webView, 10);
    const alreadySignedIn = !!(initialState && initialState.hasDashboard);

    if (alreadySignedIn) {
      console.log("Sesión AT&T reutilizada. No se requiere iniciar sesión.");
    } else {
      if (initialState && initialState.hasPassword) {
        console.log("Formulario de acceso detectado inmediatamente.");
      } else {
        console.log("No se detectó una sesión activa; se solicita acceso manual.");
      }

      const instructions = new Alert();
      instructions.title = "Sesión de AT&T";
      instructions.message =
        "AT&T no conservó una sesión activa. Inicia sesión en el portal, " +
        "completa cualquier verificación y abre Mi paquete.\n\n" +
        "Cuando veas tus GB y la barra de consumo, toca Listo. " +
        "Si AT&T mantiene la sesión, las próximas actualizaciones no deberían pedirte acceso.";
      instructions.addAction("Continuar al portal");
      instructions.addCancelAction("Cancelar");
      const choice = await instructions.present();
      if (choice === -1) throw new Error("Actualización cancelada por el usuario.");

      await webView.present();
    }

    const state = await inspectPageState(webView);
    if (!state || !state.hasDashboard) {
      console.log("No se detectó Mi paquete al terminar la navegación.");
      console.log("URL final: " + (state?.url || "desconocida"));
      throw new Error(
        "No detecté el panel de tu paquete. Abre Mi paquete y vuelve a intentarlo."
      );
    }

    const report = await inspectDashboard(webView);
    console.log("Componentes encontrados: " + report.foundComponents.join(", "));
    console.log("Longitud de texto: componentes=" + (report.componentText || "").length + ", página=" + (report.bodyText || "").length);

    const data = parseDashboardText(report);
    console.log("Lectura: " + JSON.stringify({
      totalGB: data.totalGB,
      consumedGB: data.consumedGB,
      availableGB: data.availableGB,
      percentUsed: data.percentUsed,
      daysLeft: data.daysLeft,
      expirationDate: data.expirationDate
    }));

    if (!saveCache(data)) throw new Error("No se pudo guardar la caché.");
    return data;

  } catch (error) {
    console.log("Error actualizando AT&T: " + error);
    return null;
  }
}

// ======================================================
// ELEMENTOS VISUALES — IDENTIDAD AT&T V16.4
// ======================================================

function addHeader(widget, compact = false) {
  const row = widget.addStack();
  row.centerAlignContent();
  row.spacing = 0;

  const iconTile = row.addStack();
  iconTile.size = new Size(compact ? 29 : 42, compact ? 29 : 42);
  iconTile.cornerRadius = compact ? 9 : 12;
  iconTile.backgroundColor = new Color(CONFIG.panel);
  iconTile.centerAlignContent();
  iconTile.addSpacer();
  const icon = iconTile.addImage(SFSymbol.named("antenna.radiowaves.left.and.right").image);
  icon.tintColor = new Color(CONFIG.blue);
  icon.imageSize = new Size(compact ? 15 : 21, compact ? 15 : 21);
  iconTile.addSpacer();

  row.addSpacer(compact ? 7 : 11);
  const labels = row.addStack();
  labels.layoutVertically();
  labels.spacing = 1;
  const title = labels.addText("Mi AT&T");
  title.textColor = new Color(CONFIG.white);
  title.font = Font.boldSystemFont(compact ? 13 : 19);
  const tag = labels.addText("PREPAGO");
  tag.textColor = new Color(CONFIG.blue);
  tag.font = Font.semiboldSystemFont(compact ? 8 : 10);
  row.addSpacer();
  const dots = row.addText("•••");
  dots.textColor = new Color(CONFIG.muted);
  dots.font = Font.boldSystemFont(compact ? 10 : 14);
}

function addSegmentedProgress(widget, percent, segments, height = 7, segmentWidth = 0) {
  const row = widget.addStack();
  row.spacing = height <= 5 ? 3 : 4;
  row.size = new Size(0, height);
  const used = Math.max(0, Math.min(segments, Math.round(segments * percent / 100)));
  for (let i = 0; i < segments; i++) {
    const segment = row.addStack();
    segment.size = new Size(segmentWidth > 0 ? segmentWidth : 12, height);
    segment.cornerRadius = height / 2;
    segment.backgroundColor = new Color(i < used ? CONFIG.pink : CONFIG.track);
  }
}

function addFooter(widget, data, compact = false) {
  const row = widget.addStack();
  row.centerAlignContent();
  const icon = row.addImage(SFSymbol.named("arrow.clockwise").image);
  icon.tintColor = new Color(CONFIG.muted);
  icon.imageSize = new Size(compact ? 8 : 10, compact ? 8 : 10);
  row.addSpacer(4);
  const label = row.addText("Actualizado " + formatTime(data.updatedAt));
  label.textColor = new Color(CONFIG.muted);
  label.font = Font.systemFont(compact ? 7 : 8);
  label.lineLimit = 1;
  row.addSpacer();
  const status = row.addText(data.fromCache ? "CACHÉ" : "AL DÍA");
  status.textColor = new Color(data.fromCache ? CONFIG.muted : CONFIG.green);
  status.font = Font.semiboldSystemFont(compact ? 7 : 8);
}

function addDaysLine(widget, data, compact = false) {
  const row = widget.addStack();
  row.centerAlignContent();
  const icon = row.addImage(SFSymbol.named("calendar").image);
  icon.tintColor = new Color(CONFIG.blue);
  icon.imageSize = new Size(compact ? 12 : 18, compact ? 12 : 18);
  row.addSpacer(compact ? 5 : 9);
  const text = data.daysLeft !== null && data.daysLeft !== undefined
    ? data.daysLeft + " días de vigencia" : "Vigencia no disponible";
  const label = row.addText(text);
  label.textColor = new Color(CONFIG.secondary);
  label.font = Font.semiboldSystemFont(compact ? 9 : 15);
  label.lineLimit = 1;
}

function addUsageLabels(widget, data, compact = false) {
  const row = widget.addStack();
  row.centerAlignContent();
  const used = row.addText(Math.round(data.percentUsed) + "% usado");
  used.textColor = new Color(CONFIG.pink);
  used.font = Font.semiboldSystemFont(compact ? 9 : 14);
  row.addSpacer();
  const total = row.addText(formatGB(data.totalGB) + " GB total");
  total.textColor = new Color(CONFIG.secondary);
  total.font = Font.semiboldSystemFont(compact ? 9 : 14);
}

// ======================================================
// WIDGET PEQUEÑO
// ======================================================

function createSmallWidget(data) {
  const w = new ListWidget();
  w.backgroundColor = new Color(CONFIG.background);
  w.setPadding(12, 12, 12, 12);
  w.spacing = 0;

  addHeader(w, true);
  w.addSpacer(6);

  const amount = w.addText(formatGB(data.availableGB) + " GB");
  amount.textColor = new Color(CONFIG.white);
  amount.font = Font.boldSystemFont(29);
  amount.minimumScaleFactor = 0.62;
  amount.lineLimit = 1;

  w.addSpacer(2);
  const subtitle = w.addText("Internet disponible");
  subtitle.textColor = new Color(CONFIG.secondary);
  subtitle.font = Font.semiboldSystemFont(9);
  subtitle.lineLimit = 1;

  w.addSpacer(8);
  addSegmentedProgress(w, data.percentUsed, 10, 6, 9);
  w.addSpacer(6);
  addUsageLabels(w, data, true);
  w.addSpacer(6);

  const divider = w.addStack();
  divider.size = new Size(0, 1);
  divider.backgroundColor = new Color(CONFIG.track);

  w.addSpacer(6);
  addDaysLine(w, data, true);
  w.addSpacer(6);
  // En el widget pequeño también mostramos la hora de la última lectura
  // y el indicador de caché, igual que en los tamaños mediano y grande.
  addFooter(w, data, true);
  return w;
}

// ======================================================
// WIDGET MEDIANO
// ======================================================

function createMediumWidget(data) {
  const w = new ListWidget();
  w.backgroundColor = new Color(CONFIG.background);
  w.setPadding(17, 18, 15, 18);
  w.spacing = 0;
  addHeader(w, false);
  w.addSpacer(17);

  const amount = w.addText(formatGB(data.availableGB) + " GB");
  amount.textColor = new Color(CONFIG.white);
  amount.font = Font.boldSystemFont(42);
  amount.minimumScaleFactor = 0.65;
  amount.lineLimit = 1;
  w.addSpacer(4);
  const subtitle = w.addText("Internet disponible");
  subtitle.textColor = new Color(CONFIG.secondary);
  subtitle.font = Font.semiboldSystemFont(18);
  w.addSpacer(15);

  addSegmentedProgress(w, data.percentUsed, 10, 8, 24);
  w.addSpacer(13);
  addUsageLabels(w, data, false);
  w.addSpacer(15);

  const divider = w.addStack();
  divider.size = new Size(0, 1);
  divider.backgroundColor = new Color(CONFIG.track);
  w.addSpacer(15);
  addDaysLine(w, data, false);
  w.addSpacer();
  addFooter(w, data, false);
  return w;
}

// ======================================================
// WIDGET GRANDE
// ======================================================

function createLargeWidget(data) {
  const w = new ListWidget();
  w.backgroundColor = new Color(CONFIG.background);
  w.setPadding(22, 22, 18, 22);
  w.spacing = 0;
  addHeader(w, false);
  w.addSpacer(23);

  const eyebrow = w.addText("INTERNET DISPONIBLE");
  eyebrow.textColor = new Color(CONFIG.muted);
  eyebrow.font = Font.semiboldSystemFont(10);
  w.addSpacer(3);
  const amount = w.addText(formatGB(data.availableGB) + " GB");
  amount.textColor = new Color(CONFIG.white);
  amount.font = Font.boldSystemFont(48);
  amount.minimumScaleFactor = 0.65;
  amount.lineLimit = 1;
  w.addSpacer(4);
  const subtitle = w.addText("De " + formatGB(data.totalGB) + " GB totales");
  subtitle.textColor = new Color(CONFIG.secondary);
  subtitle.font = Font.semiboldSystemFont(17);
  w.addSpacer(18);

  addSegmentedProgress(w, data.percentUsed, 18, 9, 13);
  w.addSpacer(13);
  addUsageLabels(w, data, false);

  const consumed = w.addText(formatGB(data.consumedGB) + " GB consumidos");
  consumed.textColor = new Color(CONFIG.secondary);
  consumed.font = Font.systemFont(12);
  w.addSpacer(18);
  const divider = w.addStack();
  divider.size = new Size(0, 1);
  divider.backgroundColor = new Color(CONFIG.track);
  w.addSpacer(18);
  addDaysLine(w, data, false);

  if (data.expirationDate) {
    w.addSpacer(7);
    const expiryRow = w.addStack();
    expiryRow.centerAlignContent();
    const calendarIcon = expiryRow.addImage(SFSymbol.named("calendar.badge.clock").image);
    calendarIcon.tintColor = new Color(CONFIG.blue);
    calendarIcon.imageSize = new Size(13, 13);
    expiryRow.addSpacer(7);
    const expiry = expiryRow.addText("Expira el " + formatDate(data.expirationDate));
    expiry.textColor = new Color(CONFIG.muted);
    expiry.font = Font.systemFont(11);
    expiry.lineLimit = 1;
  }

  w.addSpacer();
  addFooter(w, data, false);
  return w;
}

// ======================================================
// WIDGETS DE PANTALLA BLOQUEADA
// ======================================================

function createAccessoryWidget(data, family) {
  const w = new ListWidget();
  w.backgroundColor = null;

  if (family === "accessoryInline") {
    const text = data
      ? formatGB(data.availableGB) + " GB libres · " +
        (data.daysLeft !== null ? data.daysLeft + " días" : "Prepago")
      : "Mi AT&T · Sin datos";
    w.addText(text);
    return w;
  }

  if (family === "accessoryCircular") {
    const gauge = w.addCircularGauge();
    gauge.style = "fill";
    gauge.value = data ? Math.max(0, Math.min(1, data.availableGB / data.totalGB)) : 0;
    gauge.tintColor = new Color(CONFIG.blue);
    gauge.backgroundColor = Color.gray();
    gauge.label = "Internet";
    gauge.currentValueLabel = data
      ? formatGB(data.availableGB) + " GB"
      : "--";
    return w;
  }

  if (family === "accessoryRectangular") {
    const stack = w.addStack();
    stack.layoutVertically();

    const title = stack.addText("Mi AT&T PREPAGO");
    title.font = Font.semiboldSystemFont(11);

    const value = stack.addText(
      data ? formatGB(data.availableGB) + " GB disponibles" : "Sin datos"
    );
    value.font = Font.systemFont(10);

    const days = stack.addText(
      data && data.daysLeft !== null ? data.daysLeft + " días restantes" : "Vigencia --"
    );
    days.font = Font.systemFont(9);
    return w;
  }

  return w;
}

// ======================================================
// CREAR WIDGET SEGÚN TAMAÑO
// ======================================================

function createWidget(data) {
  const family = config.widgetFamily;
  let widget;

  if (
    family === "accessoryInline" ||
    family === "accessoryCircular" ||
    family === "accessoryRectangular"
  ) {
    widget = createAccessoryWidget(data, family);

  } else if (!data) {
    widget = new ListWidget();
    widget.backgroundColor = new Color(CONFIG.background);
    widget.setPadding(16, 16, 16, 16);

    const title = widget.addText("Mi AT&T PREPAGO");
    title.textColor = new Color(CONFIG.white);
    title.font = Font.semiboldSystemFont(13);

    widget.addSpacer(5);

    const message = widget.addText("Sin información disponible");
    message.textColor = new Color(CONFIG.secondary);
    message.font = Font.systemFont(11);

    widget.addSpacer();

    const hint = widget.addText("Abre Scriptable para actualizar");
    hint.textColor = new Color(CONFIG.muted);
    hint.font = Font.systemFont(9);

  } else if (family === "small") {
    widget = createSmallWidget(data);

  } else if (family === "large") {
    widget = createLargeWidget(data);

  } else {
    widget = createMediumWidget(data);
  }

  widget.url = URLScheme.forRunningScript();
  widget.refreshAfterDate = new Date(
    Date.now() + CONFIG.refreshIntervalMinutes * 60000
  );

  return widget;
}

// ======================================================
// EJECUCIÓN PRINCIPAL
// ======================================================

async function main() {
  if (config.runsInWidget) {
    // El widget muestra la última lectura guardada. Para renovar,
    // abre este script; refreshAfterDate no fuerza una consulta al portal.
    const cachedData = readCache();

    if (cachedData) cachedData.fromCache = true;

    const widget = createWidget(cachedData);
    Script.setWidget(widget);
    Script.complete();
    return;
  }

  const data = await updateATTData();

  if (!data) {
    const alert = new Alert();
    alert.title = "Mi AT&T V1.6 Prepago";
    alert.message =
      "No se pudo actualizar la información. " +
      "La última caché válida se conserva. " +
      "Revisa el registro de Scriptable para conocer el motivo. " +
      "Para actualizar, inicia sesión y abre Mi paquete antes de tocar Listo.";
    alert.addAction("Aceptar");
    await alert.present();
  } else {
    const alert = new Alert();
    alert.title = "Mi AT&T V1.6 Prepago";
    alert.message =
      "Información actualizada correctamente.\n\n" +
      "Disponibles: " + formatGB(data.availableGB) + " GB\n" +
      "Consumidos: " + formatGB(data.consumedGB) + " GB\n" +
      "Total: " + formatGB(data.totalGB) + " GB";
    alert.addAction("Aceptar");
    await alert.present();
  }

  Script.complete();
}

await main();
